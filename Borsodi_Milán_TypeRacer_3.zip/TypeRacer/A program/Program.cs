﻿using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace gyak
{
    internal class Program
    {
        public struct toplist
        {
            public string ido;
            public string name;
            public float szazalek;
        }
        static void Main(string[] args)
        {
            bool end = false;
            int menuvalasz = 0;
            string[] mondatok = new string[2000000];
            mondatok = beolvasas(mondatok);
            

            #region fomenu
            while (!end)
            {
                menuvalasz = menu();
                if (menuvalasz == 1)
                {
                    adatok(mondatok);
                }
                if (menuvalasz == 2)
                {
                    mondatok=ujmondat(mondatok);
                }
                if (menuvalasz == 3)
                {
                    toplista();
                }
                if (menuvalasz == 4)
                {
                    easyMode(mondatok);
                }
                if (menuvalasz == 5)
                {
                    hardMode(mondatok);
                }
                if (menuvalasz == 6)
                {
                    end = true;
                }
            }
            #endregion

        }
        static int menu()
        {
            
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.SetCursorPosition(3, 5);
            Console.WriteLine("+-----------------------------------------------------------------------------------------------------------------+");
            Console.SetCursorPosition(3, 5 + 1);
            Console.WriteLine("|  1. Mondatok listája                                                                                            |");
            Console.SetCursorPosition(3, 5 + 2);
            Console.WriteLine("|                                                                                                                 |");
            Console.SetCursorPosition(3, 5 + 3);
            Console.WriteLine("|  2. Mondat beviel                                                                                               |");
            Console.SetCursorPosition(3, 5 + 4);
            Console.WriteLine("|                                                                                                                 |");
            Console.SetCursorPosition(3, 5 + 5);
            Console.WriteLine("|  3. Toplista                                                                                                    |");
            Console.SetCursorPosition(3, 5 + 6);
            Console.WriteLine("|                                                                                                                 |");
            Console.SetCursorPosition(3, 5 + 7);
            Console.WriteLine("|  4. Játék(Könnyű)                                                                                               |");
            Console.SetCursorPosition(3, 5 + 8);
            Console.WriteLine("|                                                                                                                 |");
            Console.SetCursorPosition(3, 5 + 9);
            Console.WriteLine("|  6. Játék(Nehéz)                                                                                                |");
            Console.SetCursorPosition(3, 5 + 10);
            Console.WriteLine("|                                                                                                                 |");
            Console.SetCursorPosition(3, 5 + 11);
            Console.WriteLine("|  6. Kilépés                                                                                                     |");
            Console.SetCursorPosition(3, 5 + 12);
            Console.WriteLine("+-----------------------------------------------------------------------------------------------------------------+");
            Console.SetCursorPosition(3, 5 + 13);
            Console.WriteLine("|Szabályok: Minden elrontott betű pirossal van kiírva, ezért kapsz egy hibapontot.                                |");
            Console.SetCursorPosition(3, 5 + 14);
            Console.WriteLine("|           NEM LEHET KIHAGYNI BETŰT! (a kihagyott betűíg a [mégha helyes] szövegért hibapontot kapsz!)           |");
            Console.SetCursorPosition(3, 5 + 15);
            Console.WriteLine("+-----------------------------------------------------------------------------------------------------------------+");
            Console.SetCursorPosition(3, 5 + 16);
            Console.WriteLine("|Példa:     Az    alm a piro s                                                                                    |");
            Console.SetCursorPosition(3, 5 + 17);
            Console.Write("|           "); Console.ForegroundColor = ConsoleColor.Black; Console.BackgroundColor = ConsoleColor.Green; Console.Write("Az "); Console.ForegroundColor = ConsoleColor.Black; Console.BackgroundColor = ConsoleColor.Red; Console.Write("asd"); Console.ForegroundColor = ConsoleColor.Black; Console.BackgroundColor = ConsoleColor.Green; Console.Write("alm"); Console.ForegroundColor = ConsoleColor.Black; Console.BackgroundColor = ConsoleColor.Red; Console.Write("m"); Console.ForegroundColor = ConsoleColor.Black; Console.BackgroundColor = ConsoleColor.Green; Console.Write("a"); Console.ForegroundColor = ConsoleColor.Black; Console.BackgroundColor = ConsoleColor.Green; Console.Write(" piro"); Console.ForegroundColor = ConsoleColor.Black; Console.BackgroundColor = ConsoleColor.Red; Console.Write("S"); Console.ForegroundColor = ConsoleColor.Black; Console.BackgroundColor = ConsoleColor.Green; Console.Write("s"); Console.ForegroundColor = ConsoleColor.White; Console.BackgroundColor = ConsoleColor.Blue; Console.Write("                                                                                    |");
            Console.SetCursorPosition(3, 5 + 18);
            Console.WriteLine("+-----------------------------------------------------------------------------------------------------------------+");
            Console.SetCursorPosition(3, 5 + 19);
            Console.WriteLine("|                                                                                                                 |");
            Console.SetCursorPosition(3, 5 + 20);
            Console.WriteLine("+-----------------------------------------------------------------------------------------------------------------+");
            Console.SetCursorPosition(4, 5 + 19);

            try
            {
                return int.Parse(Console.ReadLine());
            }
            catch (FormatException)
            {
                return 0;
            }
        }
        static string[] beolvasas(string[] lista)
        {
            FileStream bruh = new FileStream("adat.txt", FileMode.Open);
            StreamReader az = new StreamReader(bruh);
            int szamolo = 0;
            while (!az.EndOfStream)
            {
                string valt = az.ReadLine();
                lista[szamolo] = valt;

                szamolo++;
            }
            Array.Resize(ref lista, szamolo);
            az.Close();
            bruh.Close();
            return lista;

        }
        static void toplista()
        {
            FileStream bruh = new FileStream("toplista.txt",FileMode.Open);
            StreamReader az = new StreamReader(bruh);
            toplist[] legjobbak = new toplist[2000000];
            int valt = 0;
            int menuveg = 0;
            Console.Clear();
            while(!az.EndOfStream)
            {
                string[] adat = az.ReadLine().Split(" ");
                legjobbak[valt].ido= adat[0];
                legjobbak[valt].name= adat[1];
                legjobbak[valt].szazalek = float.Parse(adat[2]);
                valt++;
            }
            Array.Resize(ref legjobbak, valt+1);

            Console.SetCursorPosition(3, 5);
            Console.WriteLine("+-------------------------------------------------------------------------+");
            for(int c=0;c<legjobbak.Length;c++)
            {

                Console.SetCursorPosition(3, 5+c+1);
                Console.Write(" {0} / {1} / {2}%", legjobbak[c].ido, legjobbak[c].name, legjobbak[c].szazalek);
                menuveg = c;
            }
            Console.SetCursorPosition(3, 5+menuveg+1);
            Console.WriteLine("+-------------------------------------------------------------------------+");
            az.Close();
            bruh.Close();
            Console.ReadKey();
        }
        static void toplistabamentes(int pontok,int mondathosz)
        {
            Console.Clear();
            FileStream bruh = new FileStream("toplista.txt", FileMode.Append);
            StreamWriter az = new StreamWriter(bruh);
            float szazalek = (float)pontok / (float)mondathosz;
            DateTime ido = DateTime.Now;
            string formaltido = ido.ToString("yyyy-MM-dd-HH:mm");
            string nev = "";
            Console.SetCursorPosition(3, 5);
            Console.WriteLine("+--------------------------+");
            Console.SetCursorPosition(3, 5 + 1);
            Console.WriteLine("|  NÉV(három betű):        |");
            Console.SetCursorPosition(3, 5 + 2);
            Console.WriteLine("+--------------------------+");
            Console.SetCursorPosition(22, 5 + 1);
            while(nev.Length != 3)
            {
                nev = Console.ReadLine();
                Console.SetCursorPosition(22, 5 + 1);
            }
            az.WriteLine("{0} {1} {2}",formaltido,nev,Math.Round(szazalek,2)*100);
            az.Close();
            bruh.Close();
        }
        static string[] ujmondat(string[]lista)
        {
            FileStream bruh = new FileStream("adat.txt", FileMode.Append);
            StreamWriter az = new StreamWriter(bruh);
            string uj = "";
            Console.Clear();
            Console.SetCursorPosition(3, 5);
            Console.WriteLine("+-------------------------------------------------------------------------+");
            Console.SetCursorPosition(3, 5+1);
            Console.WriteLine("   Add meg az új mondatodat:                                               ");
            Console.SetCursorPosition(3, 5 + 2);
            Console.WriteLine("                                                                           ");
            Console.SetCursorPosition(3, 5 + 3);
            Console.WriteLine("+-------------------------------------------------------------------------+");
            Console.SetCursorPosition(31, 5 + 1);
            uj = Console.ReadLine();
            az.WriteLine(uj);
            az.Close();
            bruh.Close();
            Array.Resize(ref lista, lista.Length + 1);
            lista[lista.Length-1] = uj;
            return lista;
        }
        static void adatok(string[] lista)
        {
            Console.Clear();
            for (int k = 0; k < lista.Length; k++)
            {
                Console.WriteLine("--{0}",lista[k]);
            }
            Console.ReadLine();
        }
        static void easyMode(string[] lista)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.SetCursorPosition(3, 5);
            Console.WriteLine("+--------------------------------------------+");
            Console.SetCursorPosition(3, 5+1);
            Console.WriteLine("| Készen állsz? (Nyomj ENTER-t a kezdéshez)  |");
            Console.SetCursorPosition(3, 5+2);
            Console.WriteLine("+--------------------------------------------+");
            Console.SetCursorPosition(3, 5+3);
            Console.ReadLine();
            Console.Clear();
            bool vege = false;
            while (!vege)
            {
                Random r = new Random();
                Stopwatch ora = new Stopwatch();
                string mondat = lista[r.Next(0, lista.Length)];
                string valasz = "";
                string tovabb = "";
                visszaszamlalas();

                Console.Clear();
                Console.WriteLine();
                Console.WriteLine(mondat);
                Console.WriteLine("+-----------------------------------------------------------------------------------------------------------------+");
                ora.Start();
                valasz = Console.ReadLine();
                ora.Stop();
                TimeSpan ido = ora.Elapsed;
                datas(mondat, valasz, ido);
                Console.SetCursorPosition(3, 13+1);
                Console.WriteLine("+--------------------------------------------------------------------------------------+");
                Console.SetCursorPosition(3, 13+2);
                Console.WriteLine("|       Akarsz még játszani? (Y/N)                                                     |");
                Console.SetCursorPosition(3, 13+3);
                Console.WriteLine("+--------------------------------------------------------------------------------------+");
                Console.SetCursorPosition(3, 13+4);
                Console.WriteLine("|                                                                                      |");
                Console.SetCursorPosition(3, 13+5);
                Console.WriteLine("+--------------------------------------------------------------------------------------+");
                Console.SetCursorPosition(11, 13 + 4);
                tovabb = Console.ReadLine();
                bool vissza = false;
                while (!vissza)
                {
                    if (tovabb.ToUpper() == "Y")
                    {
                        vege = false;
                        vissza = true;
                    }
                    else
                    {
                        vege = true;
                        vissza = true;
                    }
                }
                Console.Clear();
            }
        }
        static void hardMode(string[] lista)
        {
            Console.Clear();
            Console.SetCursorPosition(3, 5);
            Console.WriteLine("+--------------------------------------------+");
            Console.SetCursorPosition(3, 5 + 1);
            Console.WriteLine("| Készen állsz? (Nyomj ENTER-t a kezdéshez)  |");
            Console.SetCursorPosition(3, 5 + 2);
            Console.WriteLine("+--------------------------------------------+");
            Console.SetCursorPosition(3, 5 + 3);
            Console.ReadLine();
            Console.Clear();
            bool vege = false;
            while (!vege)
            {
                Random r = new Random();
                Stopwatch ora = new Stopwatch();
                string mondat = lista[r.Next(0, lista.Length)];
                StringBuilder valasz = new StringBuilder();
                string tovabb = "";
                visszaszamlalas();

                Console.Clear();
                Console.WriteLine();
                Console.WriteLine(mondat.Remove(mondat.Length-1,1));
                Console.WriteLine("+-----------------------------------------------------------------------------------------------------------------+");
                ora.Start();
                while (true)
                {
                    var betu = Console.ReadKey(true);
                    if (betu.Key == ConsoleKey.Enter)
                    {
                        break;
                    }
                    if (betu.Key == ConsoleKey.Backspace && valasz.Length > 0)
                    {
                        valasz.Remove(valasz.Length - 1, 1);
                    }
                    else if (betu.Key != ConsoleKey.Backspace) 
                    { 
                        valasz.Append(betu.KeyChar);
                    } 
                }
                ora.Stop();
                TimeSpan ido = ora.Elapsed;
                datas(mondat, valasz.ToString(), ido);
                Console.SetCursorPosition(3, 13 + 1);
                Console.WriteLine("+--------------------------------------------------------------------------------------+");
                Console.SetCursorPosition(3, 13 + 2);
                Console.WriteLine("|       Akarsz még játszani? (Y/N)                                                     |");
                Console.SetCursorPosition(3, 13 + 3);
                Console.WriteLine("+--------------------------------------------------------------------------------------+");
                Console.SetCursorPosition(3, 13 + 4);
                Console.WriteLine("|                                                                                      |");
                Console.SetCursorPosition(3, 13 + 5);
                Console.WriteLine("+--------------------------------------------------------------------------------------+");
                Console.SetCursorPosition(11, 13 + 4);
                tovabb = Console.ReadLine();
                bool vissza = false;
                while (!vissza)
                {
                    if (tovabb.ToUpper() == "Y")
                    {
                        vege = false;
                        vissza = true;
                    }
                    else
                    {
                        vege = true;
                        vissza = true;
                    }
                }
                Console.Clear();
            }
        }
        static void datas(string original, string valasz, TimeSpan time)
        {
            string mentes = "";
            Console.Clear();
            Console.SetCursorPosition(3, 5);
            Console.WriteLine("+--------------------------------------------------------------------------------------+");
            Console.SetCursorPosition(3, 5+1);
            Console.WriteLine(original);
            Console.SetCursorPosition(3, 5+4);
            Console.WriteLine("+--------------------------------------------------------------------------------------+");
            Console.SetCursorPosition(3, 5+5);
            int valtoriginal = 0;
            int valtvalasz = 0;
            int jok = 0;
            while(valtvalasz< valasz.Length)
            {
                if(valasz[valtvalasz] == original[valtoriginal])
                {
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.Write(valasz[valtvalasz]);
                    valtoriginal++;
                    valtvalasz++;
                    jok++;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.Blue;
                }
                else if (valasz[valtvalasz]!= original[valtoriginal])
                {
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.Write(valasz[valtvalasz]);
                    valtvalasz++;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.Blue;
                }
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.SetCursorPosition(3, 5+6);
            Console.WriteLine("+------------------------------------------------------------------------------------+");
            Console.SetCursorPosition(3, 5+7);
            Console.WriteLine("        Eltelt idő {0}-perc, {1}-másodperc                                            ",time.Minutes,time.Seconds);
            Console.SetCursorPosition(3, 5+8);
            Console.WriteLine("        Hibák száma: {0}                                                              ", original.Length-jok);
            Console.SetCursorPosition(3, 5 + 9);
            Console.WriteLine("        Eredmény mentése?(Y/N):                                                       ");
            Console.SetCursorPosition(34, 5 + 9);
            mentes = Console.ReadLine();
            if(mentes.ToUpper() == "Y")
            {
                toplistabamentes(jok,original.Length);
            }
        }
        static void visszaszamlalas()
        {
            Console.SetCursorPosition(3, 5);
            Console.WriteLine("+-------+");
            Console.SetCursorPosition(3, 5 + 1);
            Console.WriteLine("|   3   |");
            Console.SetCursorPosition(3, 5 + 2);
            Console.WriteLine("+-------+");
            Thread.Sleep(1000);
            Console.SetCursorPosition(3, 5 + 1);
            Console.WriteLine("|   2   |");
            Thread.Sleep(1000);
            Console.SetCursorPosition(3, 5 + 1);
            Console.WriteLine("|   1   |");
            Thread.Sleep(1000);
        }
    }
}